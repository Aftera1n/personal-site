# Afterain Personal Site

> Responsive personal website — desktop sidebar + mobile navigation, blue glassmorphism visual style.

一个适合部署到 Cloudflare Workers 的纯 HTML/CSS/JS 个人网站。

## 结构

- 介绍：头像、简介、三个信息卡片
- 照片动态：时间线相册，每张照片都有日期/标题/说明
- 匿名信：前端调用 `/api/letter`，由 Cloudflare Email Service 发到你的邮箱
- 此时状态：修改 `public/config.js` 即可更新现实状态

## 部署

这个项目使用 Cloudflare Workers Static Assets，一次部署静态页面 + API Worker。

1. 安装 Node.js 和 Wrangler
2. 登录：
   `npx wrangler login`
3. 在 `public/config.js` 修改自己的资料。
4. 在 Cloudflare Email Service 中为你的域名完成 Email Sending onboarding。
5. 在 Worker 的 Variables 中配置：
   - `TO_EMAIL`：你的收信邮箱
   - `FROM_EMAIL`：已经在 Cloudflare Email Service 验证/开通的发件地址
6. 部署：
   `npx wrangler deploy`

Cloudflare 官方文档：
https://developers.cloudflare.com/email-service/get-started/send-emails/
https://developers.cloudflare.com/workers/static-assets/

## R2

推荐给 R2 建一个图片专用 bucket，例如 `afterain-images`，再绑定一个自定义域名：

`img.example.com`

然后把照片上传到 R2，把得到的公开 URL 填到 `public/config.js` 的 `moments[].image`。

例如：

```js
{
  date: "2026-08-19",
  title: "今天的天空",
  description: "回家的路上拍到的。",
  image: "https://img.example.com/2026/08/19/sky.jpg"
}
```

生产环境推荐使用 R2 Custom Domain，而不是 `r2.dev`。
